package Project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDesktopPane;
import javax.swing.JOptionPane;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class LoginPage extends javax.swing.JInternalFrame {

    /**
     * Creates new form LoginPage
     */
    private Statement ps;
    public LoginPage() 
    {
        initComponents();
        
    }
    String kuldeep;
    public String setter()
    {
        kuldeep=contacttf.getText();
        //System.out.println(kuldeep);
        return kuldeep;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        textOutput1 = new datechooser.beans.editor.utils.TextOutput();
        dateChooserDialogBeanInfo1 = new datechooser.beans.DateChooserDialogBeanInfo();
        dateChooserComboBeanInfo1 = new datechooser.beans.DateChooserComboBeanInfo();
        dateChooserDialog1 = new datechooser.beans.DateChooserDialog();
        submitbtn = new javax.swing.JButton();
        contactlbl = new javax.swing.JLabel();
        contacttf = new javax.swing.JTextField();
        passwdlbl = new javax.swing.JLabel();
        passwdtf = new javax.swing.JPasswordField();
        closebtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setBackground(new java.awt.Color(255, 255, 255));
        setIconifiable(true);
        setMaximizable(true);
        setOpaque(true);
        getContentPane().setLayout(null);

        submitbtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        submitbtn.setText("Submit");
        submitbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitbtnActionPerformed(evt);
            }
        });
        getContentPane().add(submitbtn);
        submitbtn.setBounds(180, 380, 111, 39);

        contactlbl.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        contactlbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/icons8-ringing-phone-40.png"))); // NOI18N
        contactlbl.setText("   Contact");
        getContentPane().add(contactlbl);
        contactlbl.setBounds(162, 170, 190, 40);

        contacttf.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        contacttf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contacttfActionPerformed(evt);
            }
        });
        getContentPane().add(contacttf);
        contacttf.setBounds(310, 170, 226, 40);

        passwdlbl.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        passwdlbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/icons8-key-40.png"))); // NOI18N
        passwdlbl.setText("  Password");
        getContentPane().add(passwdlbl);
        passwdlbl.setBounds(160, 250, 150, 40);

        passwdtf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwdtfActionPerformed(evt);
            }
        });
        getContentPane().add(passwdtf);
        passwdtf.setBounds(310, 250, 226, 40);

        closebtn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        closebtn.setText("Close");
        closebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closebtnActionPerformed(evt);
            }
        });
        getContentPane().add(closebtn);
        closebtn.setBounds(450, 380, 111, 39);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/logincon.png"))); // NOI18N
        jLabel3.setText(" Login");
        jLabel3.setIconTextGap(1);
        jLabel3.setPreferredSize(new java.awt.Dimension(0, 0));
        getContentPane().add(jLabel3);
        jLabel3.setBounds(260, 40, 270, 103);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/kul1.png"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(360, 0, 550, 320);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/kul1.png"))); // NOI18N
        getContentPane().add(jLabel5);
        jLabel5.setBounds(0, 0, 550, 320);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/kul1.png"))); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 270, 550, 320);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/kul1.png"))); // NOI18N
        getContentPane().add(jLabel7);
        jLabel7.setBounds(360, 270, 550, 320);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/kul1.png"))); // NOI18N
        getContentPane().add(jLabel8);
        jLabel8.setBounds(180, 0, 550, 320);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Project/kul1.png"))); // NOI18N
        getContentPane().add(jLabel9);
        jLabel9.setBounds(0, 0, 550, 320);

        pack();
    }// </editor-fold>//GEN-END:initComponents
JDesktopPane pt;

    private void submitbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitbtnActionPerformed
        
        try 
        {
            Connection cnn=ConnectionDB.get();
            ps=cnn.createStatement();
            String contact=contacttf.getText();
            String passwd=passwdtf.getText();
            ResultSet rs=ps.executeQuery("select paaswd from user where phone='"+contact+"'");
            
            String a1=null;
            while(rs.next())
            {
                a1=rs.getString(1);
            }
            //System.out.println(a1);
            //System.out.println(passwd);
            if(passwd == null ? a1 == null : passwd.equals(a1))
            {
        
                this.dispose();
                AfterLogin l=new AfterLogin();
                pt.add(l);
        
                l.setVisible(true);
            }
            else
            {
                JOptionPane.showMessageDialog(this,"Password and Contact InCorrect...!");
            }
        }
        //System.out.println(a1);
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(LoginPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(LoginPage.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
//       if(a1==passwd)
  //     {
    //    
      //      this.dispose();
        //    AfterLogin l=new AfterLogin();
          // pt.add(l);
        
            //l.setVisible(true);
       //}
    }//GEN-LAST:event_submitbtnActionPerformed

    private void passwdtfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwdtfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwdtfActionPerformed

    private void closebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closebtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_closebtnActionPerformed

    private void contacttfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contacttfActionPerformed
       
        
    }//GEN-LAST:event_contacttfActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton closebtn;
    private javax.swing.JLabel contactlbl;
    private javax.swing.JTextField contacttf;
    private datechooser.beans.DateChooserComboBeanInfo dateChooserComboBeanInfo1;
    private datechooser.beans.DateChooserDialog dateChooserDialog1;
    private datechooser.beans.DateChooserDialogBeanInfo dateChooserDialogBeanInfo1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel passwdlbl;
    private javax.swing.JPasswordField passwdtf;
    private javax.swing.JButton submitbtn;
    private datechooser.beans.editor.utils.TextOutput textOutput1;
    // End of variables declaration//GEN-END:variables
}
