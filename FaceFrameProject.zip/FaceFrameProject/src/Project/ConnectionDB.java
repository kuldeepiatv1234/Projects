
package Project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDB
{
    private static Connection cnn;
    public static Connection get() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        cnn =DriverManager.getConnection("jdbc:mysql://localhost:3306/resistration", "root","root");
        return cnn;
    }
}
