
package Servlet;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class RegisterServlet extends HttpServlet
{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        
        boolean b;
        String msg="";
        PrintWriter pw1=resp.getWriter();
       
        String result=req.getParameter("res");
        if((result!=null)&&(result=="true"))
        {
            msg="Succsess";
        }
        if((result==null)&&(result=="false"))
        {
            msg="Failue";
        }
        String uname=req.getParameter("uname");
        String email=req.getParameter("email");
        String passwd=req.getParameter("passwd");
        try
        {
            File file=new File("C:\\Users\\Admin\\Documents\\NetBeansProjects\\ELibrary\\src\\java\\Servlet\\register.csv");
            FileWriter file1=new FileWriter(file,true);
            BufferedWriter writer=new BufferedWriter(file1);
            PrintWriter pw=new PrintWriter(writer);
            pw.print(email);
            pw.println(passwd);
            writer.flush();
            writer.close();
            file1.close();
            b=true;
        }
        catch(Exception ex)
        {
            System.out.println("Error:...");
            b=false;
        }
        System.out.println(b);
  
        
        resp.sendRedirect("/ELibrary/register.html?res="+b);
       
    }
}
