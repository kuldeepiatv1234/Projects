/*
package Frames;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import jdk.jfr.events.FileReadEvent;

public class Demo
{
    public static void main(String[] args)
    {
        String list[];
        FileReader file1;
        try
        {
            File file=new File("C:\\Users\\Admin\\Desktop\\Try.txt");
           // Scanner sc=new Scanner(file);
            file1 = new FileReader(file);
            BufferedReader bf=new BufferedReader(file1);
            String s="";
           // int s1;
           // FileReader fr=new FileReader("‪C:\\Users\\Admin\\Desktop\\Try.txt");
          while((s=bf.readLine()) != null)
           {
               System.out.println(s);
           }
            
            //while(sc.hasNextLine())
        //            {
           //         
           //             System.out.println(sc.nextLine());
          //          }
          //  {
           //       System.out.println(s);
          //  }
        } 
        catch (FileNotFoundException ex)
        {
            System.out.println("Eroor");
        } catch (IOException ex)
        {
            System.out.println("Error");
        }
       
    }
    
}
*/