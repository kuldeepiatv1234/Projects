
package Frames;

import java.awt.print.PrinterException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Printer extends javax.swing.JInternalFrame {
    String id;
    String cname;
    String address;
    String phone;
    String itemName;
    String Quantity1;
    String price;
    
    private  DefaultTableModel tblmodel;
  
    public Printer(String id,String cname,String address,String phone,String itemName,String Quantity1,String price)
    {
        
        initComponents();
        this.id= id;
        System.out.println("ID:"+id);
        this.cname=cname;
        System.out.println("ID:"+cname);
        this.address=address;
        this.phone=phone;
        this.itemName=itemName;
        this.Quantity1=Quantity1;
        this.price=price;
        //System.out.println(cname+":"+address+":"+phone+":"+itemName+":"+Quantity1+":"+price);
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        select = new javax.swing.JButton();
        printer = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        close = new javax.swing.JButton();
        clear = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setEnabled(false);
        setOpaque(true);
        getContentPane().setLayout(null);

        select.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        select.setText("Go");
        select.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectActionPerformed(evt);
            }
        });
        getContentPane().add(select);
        select.setBounds(410, 40, 90, 40);

        printer.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        printer.setText("Print");
        printer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printerActionPerformed(evt);
            }
        });
        getContentPane().add(printer);
        printer.setBounds(190, 440, 100, 40);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("BILL");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(420, -10, 90, 40);

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Observation", "Details"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.setCellSelectionEnabled(true);
        table.setRowHeight(24);
        jScrollPane1.setViewportView(table);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(70, 100, 770, 320);

        close.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        close.setText("Close");
        close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeActionPerformed(evt);
            }
        });
        getContentPane().add(close);
        close.setBounds(670, 440, 90, 40);

        clear.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        clear.setText("Clear");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        getContentPane().add(clear);
        clear.setBounds(440, 440, 90, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeActionPerformed
        // TODO add your handling code here:iijeijfjfejfjfc
        this.dispose();
    }//GEN-LAST:event_closeActionPerformed
    int f=0;
    private void selectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectActionPerformed
        
        
        
        if(f==0)
        {
        Float prc=Float.parseFloat(price);
        Float qt=Float.parseFloat(Quantity1);
        Float total=prc*qt;
        tblmodel=(DefaultTableModel) table.getModel();
        //System.out.println(cname+":"+address+":"+phone+":"+itemName+":"+Quantity1+":"+price);
      
        String a0="Reference ID : ";
        String a1="Customer Name : ";
        String a2="Customer Address : ";
        String a3="Customer Phone : ";
        String a4="Product Name : ";
        String a5="Product Quantity : ";
        String a6="Product Price: ";
        String a7="";
        String a8="Subtotoal : "+total;
        String a9="GST : 0.00%";
        String a10="PST : 0.00%";
        String a11="Other Taxex : 0.00%";
        String a12="TOTAL AMOUNT : "+total;
        Object array0[]={a0,id};
        tblmodel.addRow(array0);
        Object array[]={a1,cname};
        tblmodel.addRow(array);
        Object array1[]={a2,address};
        tblmodel.addRow(array1);
        Object array2[]={a3,phone};
        tblmodel.addRow(array2);
        Object array3[]={a4,itemName};
        tblmodel.addRow(array3);
        Object array4[]={a5,Quantity1};
        tblmodel.addRow(array4);
        Object array5[]={a6,price};
        tblmodel.addRow(array5);
         Object array7[]={a7,a8};
        tblmodel.addRow(array7);
        Object array8[]={a7,a9};
        tblmodel.addRow(array8);
        Object array9[]={a7,a10};
        tblmodel.addRow(array9);
        Object array10[]={a7,a11};
        tblmodel.addRow(array10);
        Object array12[]={a7,a12};
        tblmodel.addRow(array12);
        f=1;
        }        
    }//GEN-LAST:event_selectActionPerformed

    private void printerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printerActionPerformed
        
        try 
        {
            table.print();
        } 
        catch (PrinterException ex) 
        {
            Logger.getLogger(Printer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_printerActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        
        int length=tblmodel.getRowCount();
        System.out.println(length);
        for(int i=0;i<length;i++)
        {
            tblmodel.removeRow(i-i);
        }
        f=0;
    }//GEN-LAST:event_clearActionPerformed
          
   


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clear;
    private javax.swing.JButton close;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton printer;
    private javax.swing.JButton select;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
