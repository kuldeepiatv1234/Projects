package Servlet;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.validator.constraints.Length;

public class LoginServlet extends HttpServlet
{
    
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
   
        boolean b1 = false;
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime date=LocalDateTime.now();
        System.out.println(dtf.format(date));
        String email=req.getParameter("email");
        String passwd=req.getParameter("passwd");
        String mix=email+passwd;
        File f1=new File("C:\\Users\\Admin\\Documents\\NetBeansProjects\\JProject\\src\\java\\Servlet\\UserLogDetails.csv");
        FileWriter f2=new FileWriter(f1,true);
        BufferedWriter f3=new BufferedWriter(f2);
        PrintWriter pw=new PrintWriter(f3);
        pw.print(mix+":::"+dtf.format(date)+"   ");
        f3.flush();
        f3.close();
        f2.close();
        System.out.println("Mix"+mix);
        File file=new File("C:\\Users\\Admin\\Documents\\NetBeansProjects\\JProject\\src\\java\\Servlet\\register.csv");
        FileReader file1=new FileReader(file);
        BufferedReader bf=new BufferedReader(file1);
        String s="";
        int f=0;
        while((s=bf.readLine())!=null)
        {
            if(!mix.equals(s))
            {
                b1=false;
            }
            else 
            {
                b1=true;
                System.out.println("okayDonedananadaan");
                break;
            }
        }
        System.out.println(b1);
          
        if(b1==false)
        {            
        PrintWriter writer = resp.getWriter();
        

       // writer.println(htmlResp);
        } 
        else
        {
            resp.sendRedirect("/JProject/AfterLogin.html");
        }
    }

    
            
    
    
}
