package Servlet;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import javafx.util.converter.LocalDateTimeStringConverter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AfterLogin extends HttpServlet
{
    public String e;
    public String p;
 
   
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        boolean b;
      //C:\Users\Admin\Documents\NetBeansProjects\ELibrary\src\java\Servlet\UserLogDetails.csv
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime date=LocalDateTime.now();
        System.out.println(dtf.format(date));
        String branch=req.getParameter("t1");
        String course=req.getParameter("t2");
        String ebook=req.getParameter("t3");
         try
        {
            File file=new File("C:\\Users\\Admin\\Documents\\NetBeansProjects\\JProject\\src\\java\\Servlet\\UserLogDetails.csv");
            FileWriter file1=new FileWriter(file,true);
            BufferedWriter writer=new BufferedWriter(file1);
            PrintWriter pw=new PrintWriter(writer);
            pw.print("  "+branch+"  ");
            pw.print("  "+course+"  ");
            pw.print("  "+ebook+":::");
            pw.println(dtf.format(date));
            writer.flush();
            writer.close();
            file1.close();
            b=true;
        }
        catch(Exception ex)
        {
            System.out.println("Error:...");
            b=false;
        }
        resp.sendRedirect("/JProject/");    
    }
    
}
