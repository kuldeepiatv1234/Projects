
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Multi extends HttpServlet
{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        float f1=Float.parseFloat(req.getParameter("fname"));
        float f2=Float.parseFloat(req.getParameter("sname"));
        float f3=f1*f2;
        PrintWriter pw=resp.getWriter();
        pw.print("<h1> Result: "+f3+"</h1>");
    }
    
}
