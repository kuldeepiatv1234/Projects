
package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Add extends HttpServlet
{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
    {
        if(req.getParameter("b1")!=null)
        {
            PrintWriter pw=resp.getWriter();
            String n1=req.getParameter("fname");
            String n2=req.getParameter("sname");
            float f1=Float.parseFloat(n1);
            float f2=Float.parseFloat(n2);
            float f3=f1+f2;
            String n3=String.valueOf(f3);
            pw.print("<h1>Result:"+n3+"</h1>");
        }
        if(req.getParameter("b2")!=null)
        {
            float f1=Float.parseFloat(req.getParameter("fname"));
            float f2=Float.parseFloat(req.getParameter("sname"));
            float f3=f1*f2;
            PrintWriter pw=resp.getWriter();
            pw.print("<h1> Result: "+f3+"</h1>");
        }
        if(req.getParameter("b3")!=null)
        {
            float f1=Float.parseFloat(req.getParameter("fname"));
            float f2=Float.parseFloat(req.getParameter("sname"));
            float f3=f1-f2;
            PrintWriter pw=resp.getWriter();
            pw.print("<h1> Result: "+f3+"</h1>");
        }
        if(req.getParameter("b4")!=null)
        {
            float f1=Float.parseFloat(req.getParameter("fname"));
            float f2=Float.parseFloat(req.getParameter("sname"));
            float f3=f1/f2;
            PrintWriter pw=resp.getWriter();
            pw.print("<h1> Result: "+f3+"</h1>");
        }
    }
       
}
