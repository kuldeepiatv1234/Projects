package JdbcFrameWork;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDB 
{
    public static Connection cnn;
    public static Connection getterConnection() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        cnn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Office","root","root");
        return cnn;
    }
}
