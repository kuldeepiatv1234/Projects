package connectivity;

import java.awt.PageAttributes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.util.logging.Level;
//import java.util.logging.Logger;

public class Insert {

    public static void main(String[] args)
    {
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/Office","root","root");
            Statement s=c.createStatement();
            //ResultSet rs=s.executeUpdate();
            String q="insert into employee values('106','raj','14','34254354','indore')";
            int i=s.executeUpdate(q);
        } 
        catch (ClassNotFoundException ex)
        {
            System.out.println("Class not found..!");
        } catch (SQLException ex)
        {
            System.out.println("connection not established..!");
        }
        
    }
    
}
