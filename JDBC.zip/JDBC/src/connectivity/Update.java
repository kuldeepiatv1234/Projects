package connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Update 
{
    public static void main(String[] args) 
    {
        
            try 
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection c;
                c = DriverManager.getConnection("jdbc:mysql://localhost:3306/Office","root","root");
                Statement s=c.createStatement();
                String s1="update employee set name='rishabh' where id=102";
                int i=s.executeUpdate(s1);
                System.out.println(i);
            }
            
            catch (ClassNotFoundException ex) 
            {
                System.out.println("Class not found..!");
            }
            
        catch (SQLException ex) 
        {
            System.out.println("Connection not established..");
        }
    }
    
}
