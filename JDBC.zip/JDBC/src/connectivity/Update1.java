package connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Update1 
{

    public static void main(String[] args)
    {
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c;
            c=DriverManager.getConnection("jdbc:mysql://localhost:3306/Office","root","root");
            Statement s1=c.createStatement();
            Scanner sc=new Scanner(System.in);
            System.out.println("id:");
            String id=sc.next();
            System.out.println("Name:");
            String name=sc.next();
            System.out.println("Age");
            int age=sc.nextInt();
            System.out.println("Contact");
            String contact=sc.next();
            System.out.println("city:101");
            String city=sc.next();
            String update="update employee set city='"+city+"'where id='"+id+"'";
            int t=s1.executeUpdate(update);
        }
        catch (ClassNotFoundException ex) 
        {
            System.out.println("Class not found");
        } catch (SQLException ex) {
            System.out.println("Connection prob...!");
        }
        
    }
    
}
