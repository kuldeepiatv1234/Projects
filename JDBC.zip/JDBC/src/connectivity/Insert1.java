package connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.util.logging.Level;
//import java.util.logging.Logger;

public class Insert1
{
    
    public static void main(String[] args)
    {
        Connection c=null;
        
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql://localhost:3306/Office","root","root");
            Statement s=c.createStatement();
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter the id..");
            String id=sc.next();
            System.out.println("Enter the name..");
            String name=sc.next();
            System.out.println("Enshter the age..");
            int age=sc.nextInt();
            System.out.println("Enter the contact..");
            String contact=sc.next();
            System.out.println("Enter the city..");
            String city=sc.next();
            
            String query=" insert into employee values('"+id+"','"+name+"','"+age+"','"+contact+"','"+city+"') ";
            int i=s.executeUpdate(query);
        } 
        catch (ClassNotFoundException ex) 
        {
            System.out.println("Class not found....");
        } catch (SQLException ex) 
        {
            System.out.println("Connection not established....");
        }
        finally
        {
            try 
            {
                c.close();
            } 
            catch (SQLException ex)
            {
                Logger.getLogger(Insert1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
}
