
package connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {
    public static void main(String[] args)
    {
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/Office","root", "root");
            Statement s=c.createStatement();
            ResultSet rs=s.executeQuery("select * from employee");
            while(rs.next())
            {
                String id=rs.getString(1);
                String name=rs.getString(2);
                int age=rs.getInt(3);
                String contact=rs.getString(4);
                String city=rs.getString(5);
                System.out.println(id+" "+" "+name+" "+" "+age+" "+" "+contact+" "+""+city);
            }
        }
        catch (ClassNotFoundException ex) 
        {
            System.out.println("Class not found...");
        } 
        catch (SQLException ex) 
        {
            System.out.println("Connection not established...");
        }
    }
    
}
